 
//class HelloWorld {
//    public static void main(String[] args) {
//        System.out.println("Hello, World!"); 
//   }
//}
class ui {
    public interface botao {
        public static void funcao(){}
        public static void texto() {
            
        }

    }
}



