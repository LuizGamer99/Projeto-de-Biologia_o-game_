#include <stdio.h>

int main(int argc, char *argv[]){
    printf("hello world.\n");
    system("pause");
    return 0;
}